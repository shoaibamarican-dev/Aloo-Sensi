package com.aloo.sensipro

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.*
import android.webkit.*
import android.widget.*
import org.json.JSONObject

/** Hosts index.html (put it in app/src/main/assets/) and bridges it to the overlay service. */
class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "file") return false
                try {
                    if (u.scheme == "intent") {
                        val i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                        try { startActivity(i) } catch (e: Exception) {
                            i.getStringExtra("browser_fallback_url")?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
                        }
                    } else startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) { }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "AlooNative")
        OverlayService.onChange = { json ->
            runOnUiThread { web.evaluateJavascript("window.alooUpdate&&window.alooUpdate($json)", null) }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    inner class Bridge {
        @JavascriptInterface fun hasPermission(): Boolean = Settings.canDrawOverlays(this@MainActivity)
        @JavascriptInterface fun requestPermission() {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        @JavascriptInterface fun sync(json: String) {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) return@runOnUiThread
                val i = Intent(this@MainActivity, OverlayService::class.java).putExtra("cfg", json)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        }
    }
}

/** Draws the crosshair, macro buttons and the adjust panel above every other app. */
class OverlayService : Service() {
    companion object { var onChange: ((String) -> Unit)? = null }

    private lateinit var wm: WindowManager
    private var cfg = JSONObject()
    private var xhView: WebView? = null
    private var lastHtml = ""
    private val btns = HashMap<String, TextView>()
    private var panel: LinearLayout? = null

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        i?.getStringExtra("cfg")?.let { cfg = JSONObject(it); render() }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val ch = "aloo_overlay"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("ALOO SENSI PRO")
            .setContentText("Overlay is running").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun dp(v: Number) = (v.toFloat() * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, touch: Boolean): WindowManager.LayoutParams {
        var fl = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!touch) fl = fl or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, fl, PixelFormat.TRANSLUCENT)
    }

    private fun render() {
        val xh = cfg.optJSONObject("xh") ?: return
        val mc = cfg.optJSONObject("mc") ?: return
        val dm = resources.displayMetrics

        // crosshair: never touchable, so every tap goes through to the game
        if (xh.optBoolean("on")) {
            val size = dp(xh.optInt("size", 60))
            val html = "<html><body style='margin:0;background:transparent'><svg viewBox='0 0 100 100' " +
                "style='width:100%;height:100%;color:${xh.optString("c")};opacity:${xh.optDouble("o", 1.0)}'>" +
                "${xh.optString("svg")}</svg></body></html>"
            if (xhView == null) {
                xhView = WebView(this).apply { setBackgroundColor(Color.TRANSPARENT) }
                wm.addView(xhView, lp(size, size, false).apply { gravity = Gravity.CENTER })
            }
            val p = xhView!!.layoutParams as WindowManager.LayoutParams
            p.width = size; p.height = size; p.x = dp(xh.optInt("x")); p.y = dp(xh.optInt("y"))
            wm.updateViewLayout(xhView, p)
            if (html != lastHtml) { xhView!!.loadDataWithBaseURL(null, html, "text/html", "utf-8", null); lastHtml = html }
        } else { xhView?.let { wm.removeView(it) }; xhView = null; lastHtml = "" }

        // macro buttons: locked = not touchable (taps pass through), unlocked = draggable
        val keep = HashSet<String>()
        if (mc.optBoolean("on")) {
            val arr = mc.optJSONArray("btns")
            val size = dp(mc.optInt("size", 64))
            val locked = mc.optBoolean("lock")
            for (i in 0 until (arr?.length() ?: 0)) {
                val b = arr!!.getJSONObject(i)
                val id = b.optString("id"); keep.add(id)
                var v = btns[id]
                if (v == null) {
                    v = TextView(this).apply { gravity = Gravity.CENTER; setTextColor(Color.WHITE) }
                    btns[id] = v
                    wm.addView(v, lp(size, size, !locked).apply { gravity = Gravity.TOP or Gravity.START })
                    drag(v, id)
                }
                v.text = b.optString("g"); v.textSize = mc.optInt("size", 64) * 0.28f
                v.alpha = mc.optInt("o", 85) / 100f
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL; setColor(Color.parseColor(b.optString("col")))
                    setStroke(dp(2), Color.WHITE)
                }
                val p = v.layoutParams as WindowManager.LayoutParams
                p.width = size; p.height = size
                p.x = (b.optDouble("x") * dm.widthPixels - size / 2).toInt()
                p.y = (b.optDouble("y") * dm.heightPixels - size / 2).toInt()
                p.flags = if (locked) p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                          else p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                wm.updateViewLayout(v, p)
            }
        }
        btns.keys.toList().filter { it !in keep }.forEach { wm.removeView(btns.remove(it)) }

        val any = xh.optBoolean("on") || mc.optBoolean("on")
        if (any && panel == null) buildPanel()
        if (!any) { panel?.let { wm.removeView(it) }; panel = null; stopSelf() }
    }

    private fun drag(v: View, id: String) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        v.setOnTouchListener { _, e ->
            val p = v.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> { p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(v, p) }
                MotionEvent.ACTION_UP -> {
                    val d = resources.displayMetrics
                    val fx = (p.x + p.width / 2f) / d.widthPixels; val fy = (p.y + p.height / 2f) / d.heightPixels
                    onChange?.invoke("{\"btn\":{\"id\":\"$id\",\"x\":$fx,\"y\":$fy}}")
                }
            }
            true
        }
    }

    private fun change(field: String, d: Int) {
        val xh = cfg.optJSONObject("xh") ?: return
        val r = if (field == "size") 20..200 else -160..160
        val v = (xh.optInt(field) + d).coerceIn(r.first, r.last)
        xh.put(field, v); render()
        onChange?.invoke("{\"xh\":{\"$field\":$v}}")
    }

    private fun toggleLock() {
        val mc = cfg.optJSONObject("mc") ?: return
        val l = !mc.optBoolean("lock"); mc.put("lock", l); render()
        onChange?.invoke("{\"mc\":{\"lock\":$l}}")
    }
    private fun nextStyle() { onChange?.invoke("{\"cmd\":\"next\"}") }
    private fun closeAll() {
        cfg.optJSONObject("xh")?.put("on", false); cfg.optJSONObject("mc")?.put("on", false); render()
        onChange?.invoke("{\"xh\":{\"on\":false},\"mc\":{\"on\":false}}")
    }
    private fun macroOp(d: Int) {
        val mc = cfg.optJSONObject("mc") ?: return
        val v = (mc.optInt("o", 85) + d).coerceIn(25, 100); mc.put("o", v); render()
        onChange?.invoke("{\"mc\":{\"o\":$v}}")
    }
    private fun macroToggle() {
        val mc = cfg.optJSONObject("mc") ?: return
        val on = !mc.optBoolean("on"); mc.put("on", on); render()
        onChange?.invoke("{\"mc\":{\"on\":$on}}")
    }

    private fun buildPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E60E0A22")); cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#5A4AA8"))
            }
        }
        val title = TextView(this).apply { text = "✛ AIM  (drag me)"; setTextColor(Color.CYAN); textSize = 11f }
        root.addView(title)
        fun row(vararg items: Pair<String, () -> Unit>) {
            val r = LinearLayout(this)
            items.forEach { (label, act) ->
                val b = Button(this); b.text = label; b.textSize = 12f; b.setPadding(0, 0, 0, 0)
                b.minWidth = 0; b.minimumWidth = 0; b.setOnClickListener { act() }
                r.addView(b, LinearLayout.LayoutParams(dp(44), dp(40)))
            }
            root.addView(r)
        }
        row("A−" to { change("size", -4) }, "A+" to { change("size", 4) }, "🔒" to { toggleLock() })
        row("◀" to { change("x", -3) }, "▶" to { change("x", 3) }, "↻" to { nextStyle() })
        row("▲" to { change("y", -3) }, "▼" to { change("y", 3) }, "✕" to { closeAll() })
        root.addView(TextView(this).apply { text = "MACRO  (opacity / on-off)"; setTextColor(Color.parseColor("#A79FC9")); textSize = 10f })
        row("Op−" to { macroOp(-10) }, "Op+" to { macroOp(10) }, "◉" to { macroToggle() })
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, true)
            .apply { gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(120) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> { p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, p) }
            }
            true
        }
        wm.addView(root, p); panel = root
    }

    override fun onDestroy() {
        xhView?.let { wm.removeView(it) }; btns.values.forEach { wm.removeView(it) }; panel?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
