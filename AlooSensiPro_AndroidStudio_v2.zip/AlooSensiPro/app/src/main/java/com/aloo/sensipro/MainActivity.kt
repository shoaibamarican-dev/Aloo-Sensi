package com.aloo.sensipro

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject

/** Hosts assets/index.html and bridges it to the overlay service. */
class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0A0C14"))
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.setSupportZoom(false)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "file") return false
                try {
                    if (u.scheme == "intent") {
                        val i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                        i.addCategory(Intent.CATEGORY_BROWSABLE)
                        i.component = null
                        i.selector = null
                        try { startActivity(i) } catch (e: Exception) {
                            i.getStringExtra("browser_fallback_url")?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
                        }
                    } else startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) { }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "AlooNative")
        OverlayService.onChange = { json ->
            runOnUiThread { web.evaluateJavascript("window.alooUpdate&&window.alooUpdate($json)", null) }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        OverlayService.onChange = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    /** Opens a social page in the real app (tries every known package), then falls back to the browser. */
    private fun openSocial(kind: String) {
        val url: String
        val pkgs: List<String>
        if (kind == "tiktok") {
            url = "https://www.tiktok.com/@aloo.pc"
            pkgs = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go")
        } else {
            url = "https://www.youtube.com/@nexo4444-1"
            pkgs = listOf("com.google.android.youtube")
        }
        for (p in pkgs) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(p))
                return
            } catch (e: ActivityNotFoundException) {
            } catch (e: Exception) {
            }
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Link open nahi hua: $url", Toast.LENGTH_LONG).show()
        }
    }

    inner class Bridge {
        @JavascriptInterface fun hasPermission(): Boolean = Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface fun requestPermission() {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }

        @JavascriptInterface fun openLink(kind: String) {
            runOnUiThread { openSocial(kind) }
        }

        /** Last config the overlay knew (it may have been edited from the floating menu while the app was closed). */
        @JavascriptInterface fun getState(): String = OverlayService.savedState(this@MainActivity)

        @JavascriptInterface fun menu(state: String) {
            runOnUiThread { OverlayService.instance?.setMenu(state) }
        }

        @JavascriptInterface fun sync(json: String) {
            runOnUiThread {
                OverlayService.save(this@MainActivity, json)
                if (!Settings.canDrawOverlays(this@MainActivity)) return@runOnUiThread
                val running = OverlayService.instance
                val any = try {
                    val o = JSONObject(json)
                    (o.optJSONObject("xh")?.optBoolean("on") ?: false) || (o.optJSONObject("mc")?.optBoolean("on") ?: false)
                } catch (e: Exception) { false }
                try {
                    if (running != null) running.applyConfig(json)
                    else if (any) {
                        val i = Intent(this@MainActivity, OverlayService::class.java).putExtra("cfg", json)
                        startForegroundService(i)
                    }
                } catch (e: Exception) { }
            }
        }
    }
}
